from setuptools import setup, find_packages
setup(
    name='datavalidator-Mr_Lit',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='Lawal Idris T.',
    author_email='olatomiwal679@gmail.com',
    description='A simple data validation package'
)